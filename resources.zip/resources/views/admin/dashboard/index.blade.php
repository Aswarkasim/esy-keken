<div class="row mt-2">
    <div class="col-md-3">
      <div class="info-box">
        <span class="info-box-icon bg-primary elevation-1"><i class="fas fa-chalkboard-teacher"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Total Kelas</span>
          <span class="info-box-number">
            {{$kelas}}
            <small>Kelas</small>
          </span>
  
        </div>
      </div>
      <!-- /.info-box -->
    </div>
{{-- Adakah --}}
    <div class="col-md-3">
        <div class="info-box">
          <span class="info-box-icon bg-success elevation-1"><i class="fas fa-users"></i></span>
          <div class="info-box-content">
            <span class="info-box-text">Total Lowongan</span>
            <span class="info-box-number">
              {{$lowongan}}
              <small>Lowongan</small>
            </span>
    
          </div>
        </div>
        <!-- /.info-box -->
      </div>

</div>  